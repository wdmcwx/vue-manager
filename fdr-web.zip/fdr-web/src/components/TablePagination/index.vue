<!--
 * @Descripttion: 对表格的封装操作，实现表格的分页、行点击、行选中等功能
 * @version:
 * @Author:
 * @Date: 2019-12-12 17:25:02
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-12 20:11:28
 -->
<template>
  <div class="table-pagination clearfix">
    <el-table
      ref="table"
      :data="showList"
      :max-height="height"
      border
      @sort-change="sortChange"
      @row-click="rowClick"
      @selection-change="selectionChange"
      :row-class-name="tableRowClassName">
      <slot></slot>
    </el-table>
    <el-pagination
      v-if="total > 0"
      style="margin-top: 22px;"
      background
      :current-page="currentPage"
      :page-sizes="pageSizes"
      :page-size="pageSize"
      :layout="layout"
      :total="total"
      @current-change="currentChange"
      @size-change="sizeChange"
    >
    </el-pagination>
  </div>
</template>

<script>
export default {
  name: '',
  data() {
    const { currentPage, pageSize, pageSizes, layout } = this.initPagination
    // 此处判断是否是服务端分页，前端分页与服务端分页获取的表格数据形式不同。
    const showList = !this.service ? this.changeShowList(currentPage, pageSize, this.tableData) : this.tableData.data
    return {
      currentPage: currentPage, // 当前第几页
      pageSize: pageSize, // 每页条数
      pageSizes: pageSizes, // 总共页数
      layout: layout, // 分页布局
      showList: showList, // 数据源（区分服务端、前端分页）
      tableList: this.tableData, // 数据源（未经区分前端分页，服务端分页）
      selectionList: [] // table 选中的行数据信息 （允许多选行的时候使用）
    }
  },
  props: {
    tableData: { // 表格数据源
      type: [Array, Object],
      default: () => ([])
    },
    initPagination: { // 分页样式布局
      type: Object,
      default: () => ({
        currentPage: 1,
        pageSize: 10,
        pageSizes: [5, 10, 20, 50],
        layout: 'slot, total, sizes, ->, prev, pager, next, jumper'
      })
    },
    height: { // 表格高度
      type: Number,
      default: 530
    },
    highlightCurrentRow: { // 高亮当前行
      type: Boolean,
      default: false
    },
    singleSelect: { // 是否只能单选
      type: Boolean,
      default: false
    },
    service: { // 服务端分页
      type: Boolean,
      default: false
    }
  },
  computed: {
    total() {
      if (this.service) return this.tableData.totalSize
      return this.tableData.length
    }
  },
  mounted() {
  },
  methods: {
    // 获取指定页数数据 (前端分页)
    changeShowList(currentPage, pageSize, tableList = this.tableList) {
      const from = (currentPage - 1) * pageSize
      return tableList.slice(from, from + pageSize)
    },
    currentChange(cur) { // 当前页发生变化的时候
      this.currentPage = cur
      if (this.service) { // 服务端分页
        this.$emit('service-fn', { pageNum: cur })
        return
      }
      // 前端分页
      this.showList = this.changeShowList(this.currentPage, this.pageSize)
    },
    sizeChange(size) { // 每页条数发生变化时候触发
      this.pageSize = size
      if (this.service) {
        this.$emit('service-fn', { pageSize: size })
        return
      }
      this.showList = this.changeShowList(this.currentPage, this.pageSize)
    },
    sortChange({ column, order, prop }) { // 表格排序
      if (this.service) {
        let sortBy = ''

        if (order) {
          sortBy = column.sortBy || prop
        }

        const orderBy = order ? `${sortBy} ${order.replace('ending', '')}` : ''
        this.$emit('service-fn', { orderBy })
        return
      }

      this.$emit('sort-change', { column, order, prop })
    },
    rowClick(row, event, column) { // 行点击
      this.$emit('row-click', row, event, column, this.singleSelect)
      const isSelected = this.selectionList.includes(row) // 判断点击行是否已经被选中过
      this.toggleRowSelection(row, !isSelected) // 切换选中的状态
    },
    selectionChange(selection) { // checkbox 勾选中的行数据
      this.selectionList = selection
    },
    tableRowClassName(row) { // 每行的 className 回调
      let classNames = 'table-list-body'
      this.selectionList.forEach(item => {
        if (row.row === item) {
          classNames = 'table-list-body row-selected'
        }
      })
      return classNames
    },
    toggleRowSelection(row, selected) { // 切换某一行的选中状态
      this.$refs.table.toggleRowSelection(row, selected)
    }
  }
 }
</script>

<style scoped rel="stylesheet/scss" lang="scss"></style>