/*
 * @Descripttion: 
 * @version:
 * @Author:
 * @Date: 2019-12-11 19:21:53
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-12 17:22:28
 */
const app = {
  state: {
    tagView: [],
    activeTag: {} // 当前激活项
  },
  mutations: {
    PUSH_TAGVIEW: (state, tagview) => {
      state.tagView.push(tagview)
    },
    REMOVE_TAGVIEW: (state, tag) => {
      const index = state.tagView.findIndex(item => {
        return item.path === tag.path
      })
      state.tagView.splice(index, 1)
    },
    REMOVE_TAGVIEW_ALL: (state) => {
      state.tagView.length = 0
    },
    SET_ACTIVETAG: (state, tag) => {
      state.activeTag = tag
    }
  }
}
export default app