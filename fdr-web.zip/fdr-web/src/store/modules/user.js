/*
 * @Descripttion: 
 * @version: 
 * @Author: 
 * @Date: 2019-12-10 16:43:17
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-11 19:23:02
 */
import {
  getToken,
  // setToken,
  // removeToken
} from 'utils/auth'
import {
  constantRouterMap
} from 'router'

const user = {
  state: {
    eToken: getToken(),
    user: '', // loginName
    name: '', // userName
    permission: [],
    routers: constantRouterMap
  },
  mutations: {
    SAVE_TOKEN: (state, eToken) => {
      state.eToken = eToken
    }
  },
  actions: {
    
  }
}

export default user