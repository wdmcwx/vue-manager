/*
 * @Descripttion: 
 * @version: 
 * @Author: 
 * @Date: 2019-12-10 16:43:01
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-12 09:29:34
 */
const getters = {
  token: state => state.user.etoken,
  user: state => state.user.user,
  name: state => state.user.name,
  permission_info: state => state.user.permission,
  permission_routers: state => state.user.routers,
  tagViews: state => state.app.tagView,
  activeTag: state => state.app.activeTag
}
export default getters