/*
 * @Descripttion: 
 * @version: 
 * @Author: 
 * @Date: 2019-12-10 16:42:50
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-11 19:32:59
 */
import Vue from 'vue'
import Vuex from 'vuex'
import getters from './getters'
import user from './modules/user'
import app from './modules/app'

Vue.use(Vuex)

export default new Vuex.Store({
  modules: {
    user,
    app
  }, 
  getters
})