/*
 * @Descripttion: 封装一些常用函数
 * @version: 
 * @Author: 
 * @Date: 2019-12-10 17:51:15
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-11 14:53:26
 */
// 函数防抖：任务频繁触发的情况下，只有任务触发的时间间隔超过指定间隔的时候，任务才会执行。
export function debounce(fn, interval = 300) {
  let timeout = null
  return function() {
    timeout ? clearTimeout(timeout) : ''
    timeout = setTimeout(() => {
      fn.apply(this, arguments)
      timeout = null
    }, interval)
  }
}

function isObject(obj) {
  return typeof obj === 'object'
}
// 深拷贝
export function deepClone(obj) {
  if (!isObject(obj)) {
    throw new Error(`${obj} 不是一个对象`)
  }
  let isArray = Array.isArray(obj)
  let cloneObj = isArray ? [...obj] : {...obj}
  Reflect.ownKeys(cloneObj).forEach(key => {
    cloneObj[key] = isObject(obj[key]) ? deepClone(obj[key]) : obj[key]
  })
  return cloneObj
}