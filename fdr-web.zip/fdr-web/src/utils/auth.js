/*
 * @Descripttion: cookie 存取 token
 * @version:
 * @Author:
 * @Date: 2019-12-11 11:36:07
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-11 11:37:48
 */
import Cookies from 'js-cookie'

const TokenKey = 'ACCESS_TOKEN'

export function getToken() {
  return Cookies.get(TokenKey)
}

export function setToken(token) {
  return Cookies.set(TokenKey, token)
}

export function removeToken() {
  return Cookies.remove(TokenKey)
}
