/*
 * @Descripttion: 路由配置
 * @version:
 * @Author:
 * @Date: 2019-12-10 18:36:56
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-11 16:55:30
 */
import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const RouterView = () => import('views/layout/RouterView')
export const constantRouterMap = [
  {
    path: '/login',
    hidden: true,
    component: () => import('views/login')
  },
  {
    path: '/',
    name: 'index',
    component: () => import('views/layout'),
    children: [
      {
        path: '/test1',
        name: 'test1',
        icon: 'el-icon-user',
        parent: '/',
        component: () => import('views/fdr/test1')
      },
      {
        path: '/test2',
        name: 'test2',
        icon: 'el-icon-phone-outline',
        parent: '/',
        component: () => import('views/fdr/test2')
      },
      {
        path: '/test3',
        name: 'test3',
        icon: 'el-icon-star-off',
        parent: '/',
        component: () => import('views/fdr/test3')
      },
      {
        path: '/test4',
        name: 'test4',
        icon: 'el-icon-setting',
        parent: '/',
        // RouterView 承载该目录下的所有页面
        component: RouterView,
        children: [
          {
            path: '/test4/child1',
            name: 'child1',
            icon: '',
            parent: 'test4',
            component: () => import('views/fdr/test4/child1')
          },
          {
            path: '/test4/child2',
            name: 'child2',
            icon: '',
            parent: 'test4',
            component: () => import('views/fdr/test4/child2')
          },
          {
            path: '/test4/child3',
            name: 'child3',
            icon: '',
            parent: 'test4',
            component: RouterView,
            children: [
              {
                path: '/test4/child3/child',
                name: 'child',
                icon: '',
                parent: 'test4/child3',
                component: () => import('views/fdr/test4/child3/child')
              }
            ]
          }
        ]
      }
    ]
  }
]
export default new Router({
  routes: constantRouterMap
})