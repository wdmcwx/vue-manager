/*
 * @Descripttion: 所有请求路由
 * @version:
 * @Author:
 * @Date: 2019-12-12 17:26:23
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-12 17:27:45
 */

 // 登录登出
export const LOGIN_LOGOUT = {
  LOGIN: '/login'
}