<!--
 * @Descripttion: 
 * @version: 
 * @Author: 
 * @Date: 2019-12-10 18:14:10
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-12 17:14:52
 -->
<template>
  <div class="login-wrapper">
    <el-form :model="loginForm" :rules="loginRules"
      ref="loginForm" label-position="left" label-width="0px" class="card-box login-form">
      <el-form-item prop="loginName">
        <span class="icon-container"></span>
        <el-input name="loginName" type="text" v-model="loginForm.loginName" placeholder="用户名" size="small"></el-input>
      </el-form-item>
      <el-form-item prop="password">
        <span class="icon-container"></span>
        <el-input name="password" type="password" @keyup.enter="handleLogin" v-model="loginForm.password"
          placeholder="密码" size="small"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" size="small" style="width:100%;" :loading="loading" @click.prevent="handleLogin">
          查询
        </el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
export default {
  name: '',
  data() { 
    return {
      loginForm: {
        loginName: '',
        password: ''
      },
      loginRules: {
        loginName: [
          { required: true, trigger: 'blur', message: '请输入用户名' }
        ],
        password: [
          { required: true, trigger: 'blur', message: '请输入密码' }
        ]
      },
      loading: false
    }
  },
  props: {
  },
  components: {
  },
  mounted() {
  },
  methods: {
    handleLogin() {
      this.$refs.loginForm.validate(valid => {
        if (valid) {
          this.loading = true
          setTimeout(() => { // 此处模拟异步登录
          this.loading = false
            this.$router.push({path: '/'})
          }, 500);
        } else {
          return false
        }
      })
    }
  }
 }
</script>

<style scoped rel="stylesheet/scss" lang="scss">
$distance14: 14%;
.login-wrapper {
  height: 100vh;
  background-image: url('../../assets/login.png');
  background-size: cover;
  background-repeat: no-repeat;
  position: relative;
  .login-form{
    position: absolute;
    bottom: $distance14;
    right: $distance14;
  }
}
</style>