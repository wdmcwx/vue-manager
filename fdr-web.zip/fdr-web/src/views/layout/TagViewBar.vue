<!--
 * @Descripttion: 
 * @version: 
 * @Author: 
 * @Date: 2019-12-11 19:08:23
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-12 16:41:00
 -->
<template>
  <div class="tagview-wrapper">
    <el-tag
      :key="tag.path"
      v-for="tag in tagViews"
      closable
      :disable-transitions="false"
      :class="activeTag.path === tag.path ? 'active-tag' : ''"
      @close="handleClose(tag)">
      {{tag.name}}
    </el-tag>
  </div>
</template>

<script>
import { mapGetters, mapMutations } from 'vuex'
import { deepClone } from 'utils'
export default {
  name: '',
  data() {
    return {}
  },
  props: {
    closeType: String
  },
  watch: {
    closeType(val) {
      // 批量删除
      this.deleteBatches(val.split('-')[0])
    }
  }, 
  computed: {
    ...mapGetters(['activeTag', 'tagViews'])
  },
  methods: {
    ...mapMutations (['REMOVE_TAGVIEW' , 'SET_ACTIVETAG', 'REMOVE_TAGVIEW_ALL']),
    handleClose(tag) {
      const removeIndex = this.tagViews.findIndex(item => item.path === tag.path)
      const isActiveTag = tag.path === this.activeTag.path
      if (isActiveTag) { // 删除 tag 是当前激活项
        const currentActiveIndex = this.setCurrentActiveIndex(removeIndex)
        const activeItem = this.tagViews[currentActiveIndex]
        // 设置激活的 tagview 项
        this.SET_ACTIVETAG(activeItem)
        // 映射 main 区域显示的页面
        this.mapMainArea(currentActiveIndex, activeItem)
      }
      // 重新设置 tagview 数组
      this.REMOVE_TAGVIEW(tag)
    },
    deleteBatches(closeType) {
      // this.REMOVE_TAGVIEW_ALL() 不生效 ？
      const deleteTagView = deepClone(this.tagViews) // 深拷贝
      if (closeType === 'all') {
        deleteTagView.forEach(item => {
          this.REMOVE_TAGVIEW(item)
        })
        this.$router.push({path: '/'}) // 路由回到根目录
      }
      if (closeType === 'other') {
        deleteTagView.forEach(item => {
          if (item.path !== this.activeTag.path) {
            this.REMOVE_TAGVIEW(item)
          }
        })
      } 
    },
    setCurrentActiveIndex(removeIndex) {
      let currentActiveIndex = -1
      if(removeIndex + 1 < this.tagViews.length - 1) { // 存在往后一个 tag
        currentActiveIndex = removeIndex + 1
      }
      if (0 < removeIndex - 1 < this.tagViews.length) { // 存在往前一个 tag
        currentActiveIndex = removeIndex - 1
      }
      return currentActiveIndex
    },
    mapMainArea(currentActiveIndex, activeItem) {
      if (currentActiveIndex === -1) { // tagview 数组已经清空完整，默认跳转到根目录
        this.$router.push({path: '/'})
      } else {
        this.$router.push({path: activeItem.path})
      }
    }
  }
 }
</script>

<style rel="stylesheet/scss" lang="scss">
</style>