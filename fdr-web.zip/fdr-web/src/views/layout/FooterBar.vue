<!--
 * @Descripttion: 底部展区
 * @version:
 * @Author:
 * @Date: 2019-12-10 19:24:55
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-12 17:42:49
 -->
<template>
  <div class="">
    footerBar
  </div>
</template>

<script>
export default {
  name: '',
  data() { 
    return {

    }
  },
  props: {
  },
  components: {
  },
  mounted() {
  },
  methods: {
  }
 }
</script>

<style scoped rel="stylesheet/scss" lang="scss">
</style>