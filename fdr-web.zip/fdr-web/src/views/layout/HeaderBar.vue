<!--
 * @Descripttion: 头部
 * @version:
 * @Author:
 * @Date: 2019-12-10 19:25:05
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-12 16:44:22
 -->
<template>
  <div class="headerbar-container">
    <div class="header-left">
      <span class="trigger" @click="trigger">
        <i class="el-icon-s-unfold" v-if="!isCollapse"></i>
        <i class="el-icon-s-fold" v-if="isCollapse"></i>
      </span>
    </div>
    <div class="nav-container">
      <TagViewBar :closeType="closeType"></TagViewBar>
    </div>
    <div class="header-right">
      <div class="close">
        <el-dropdown trigger="click" @command="(value) => {clickDropdown(value, 'close')}">
          <span> 关闭操作 
            <i class="el-icon-arrow-down el-icon--right"></i>
          </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item :command="closeObj.other">关闭其他</el-dropdown-item>
            <el-dropdown-item :command="closeObj.all">关闭所有</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>
      <div class="user">
        <el-dropdown trigger="click" @command="(value) => {clickDropdown(value, 'user')}">
          <span> welcome xx 
            <i class="el-icon-user"></i>
          </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item :command="closeObj.edit">修改个人信息</el-dropdown-item>
            <el-dropdown-item :command="closeObj.logout">退出登录</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>
    </div>
  </div>
</template>

<script>
import TagViewBar from './TagViewBar'
export default {
  name: '',
  data() { 
    return {
      isCollapse: this.collapse,
      closeObj: {
        other: 'other',
        all: 'all',
        edit: 'edit',
        logout: 'logout'
      },
      closeType: ''
    }
  },
  props: {
    collapse: Boolean
  },
  components: { TagViewBar },
  mounted() {
  },
  methods: {
    trigger() {
      this.isCollapse = !this.isCollapse
      this.$emit('update:collapse', this.isCollapse)
    },
    clickDropdown(command, type) {
      if (type === 'close') {
        this.closeType = `${command}-${(new Date().getTime())}`
      }
      if (type === 'user') {
        if (command === this.closeObj.logout) { // 退出登录
          this.$router.push({path: '/login'})
        }
      }
    }
  }
 }
</script>