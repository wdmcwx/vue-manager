<!--
 * @Descripttion: 侧边栏
 * @version: 
 * @Author:
 * @Date: 2019-12-10 19:25:28
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-11 19:17:54
 -->
<template>
  <div class="sidebar-wrapper">
    <el-scrollbar tag="div">
      <el-menu :collapse="!collapse" unique-opened >
        <siderbar-item
          v-for="(menu, index) in routes"
          :key="index"
          :routes="menu"
        />
      </el-menu>
    </el-scrollbar>
  </div>
</template>

<script>
import { constantRouterMap } from 'router'
import { mapGetters } from 'vuex'
import { deepClone } from 'utils'
import SiderbarItem from './SiderbarItem'

export default {
  name: 'Siderbar',
  data() { 
    return {
      isTransition: false
    }
  },
  props: {
    collapse: Boolean
  },
  components: { SiderbarItem },
  watch: {
    permission_routers(val) {
      // console.log('permission_routers ==>', val)
    }
  },
  computed: {
    ...mapGetters([
      'permission_routers'
    ]),
    routes() {
      return deepClone(this.permission_routers)[1].children
    }
  },
  mounted() {
    // console.log('routes ==>', this.routes)
  },
  methods: {
  }
 }
</script>

<style scoped rel="stylesheet/scss" lang="scss">
.sidebar-wrapper {
  .el-menu--collapse{
    width: 100%;
  }
}
</style>