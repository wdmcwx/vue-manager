<!--
 * @Descripttion: 所有路由显示页面
 * @version:
 * @Author:
 * @Date: 2019-12-11 16:47:40
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-12 17:42:18
 -->
<template>
  <router-view/>
</template>
