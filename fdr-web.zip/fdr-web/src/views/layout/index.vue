<!--
 * @Descripttion: 整体项目布局
 * @version:
 * @Author:
 * @Date: 2019-12-10 18:21:24
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-12 17:41:13
 -->
<template>
  <div class="layout">
    <div :class="siderBarWidth">
      <div class="logo"><img :src="logo"/></div>
      <sider-bar class="side-bar" :collapse="isCollapse"></sider-bar>
    </div>
    <div class="right">
      <!-- sync修饰符的使用，免去了监听子组件传递过来的值 -->
      <header-bar class="header" :collapse.sync="isCollapse"></header-bar>
      <app-main class="main"></app-main>
      <footer-bar class="footer"></footer-bar>
    </div>
  </div>
</template>

<script>
import AppMain from './AppMain'
import FooterBar from './FooterBar'
import HeaderBar from './HeaderBar'
import SiderBar from './SiderBar'

export default {
  name: '',
  data() { 
    return {
      isCollapse: true,
      screenWidth: document.body.clientWidth,
      siderBarWidth: 'left left-width250',
      logo: require('assets/logo.png')
    }
  },
  props: {},
  components: {
    AppMain, HeaderBar, SiderBar, FooterBar
  },
  watch: {
    isCollapse(val) {
      this.calculateSideBarWidth(val)
    },
    screenWidth(val) {
      /** 为了避免频繁触发resize函数导致页面卡顿，使用定时器 */
      if (!this.timer) {
        this.screenWidth = val
        this.timer = true
        setTimeout(() => {
          if (this.screenWidth < 1400) {
            this.isCollapse = false
          } else {
            this.isCollapse = true
          }
          this.timer = false
        }, 400)
      }
    }
  },
  mounted() {
    this.calculateSideBarWidth(this.isCollapse)
    window.onresize = () => {
      return (() => {
        window.screenWidth = document.body.clientWidth
        this.screenWidth = window.screenWidth
      })()
    }

    this.handleBro()
  },
  methods: {
    calculateSideBarWidth(isCollapse) {
      this.siderBarWidth = isCollapse ? 'sidebar-wrapper left-width250' : 'sidebar-wrapper left-width100'
    },
    handleBro() {
      if (this.screenWidth < 1400) {
        this.isCollapse = false
      } else {
        this.isCollapse = true
      }
    },
    handleCloseTag() {

    }
  }
 }
</script>

<style rel="stylesheet/scss" lang="scss">
@mixin custom_border {
  border: 1px solid rgb(177, 180, 166);
  box-sizing: border-box;
};

$header_footer_height: 50px;
$header_border: 1px #D4D4D4 solid;
.layout {
  display: flex;
  height: 100vh;
  .sidebar-wrapper {
    transition: width 0.28s ease-out;
    .logo {
      img {
        width: 100%;
      }
    }
  }
  .left-width250 {
    width: 184px;
  }
  .left-width100 {
    width: 100px;
  }
  .right {
    flex: 1;
    .header {
      height: $header_footer_height;
      line-height: $header_footer_height;
      border-bottom: $header_border;
      box-sizing: border-box;
    }
    .main {
      height: calc(100% - 2*#{$header_footer_height});
    }
    .footer {
      height: $header_footer_height;
      @include custom_border
    }
  }
}
</style>