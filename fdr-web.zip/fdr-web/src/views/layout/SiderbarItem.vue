<!--
 * @Descripttion: 递归调用自身组件生成侧边栏条目
 * @version:
 * @Author:
 * @Date: 2019-12-11 15:35:20
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-12 09:33:56
 -->
<template>
  <div class="">
    <el-submenu :index="routes.path"
      v-if="routes.children && routes.children.length > 0">
      <template slot="title">
        <i class="el-icon-fa" :class="routes.icon" v-if="routes.icon"></i>
        <span>{{ routes.name }}</span>
      </template>
      <!-- siderbar-item 递归调用自身 -->
      <siderbar-item
        v-for="children in routes.children"
        :index="children.path"
        :key="children.path"
        :routes="children"
      />
    </el-submenu>
    <router-link :to="routes.path" v-else>
      <el-menu-item :index="routes.path" @click="ItemClick">
        <i class="el-icon-fa" :class="routes.icon" v-if="routes.icon"></i>
        <span slot="title">{{ routes.name }}</span>
      </el-menu-item>
    </router-link>
  </div>
</template>

<script>
import { mapGetters, mapMutations } from 'vuex'
export default {
  name: 'SiderbarItem',
  data() { 
    return {

    }
  },
  props: {
    routes: Object,
    isroot: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    ...mapGetters([
      'tagViews'
    ])
  },
  methods: {
    ...mapMutations (['PUSH_TAGVIEW', 'SET_ACTIVETAG']),
    ItemClick() {
      // this.routes 目前sidebar 单击选中的项
      // 记录激活的路由
      this.SET_ACTIVETAG(this.routes)     
      const isExist = this.tagViews.find(item => {
        return item.name === this.routes.name
      })
      if (isExist) { // 头部 tagview 已经展示，不允许重复添加
        return
      }
      this.PUSH_TAGVIEW(this.routes) // 记录头部 tagview
    }
  }
 }
</script>

<style scoped rel="stylesheet/scss" lang="scss">
a {
  text-decoration: none
}
</style>