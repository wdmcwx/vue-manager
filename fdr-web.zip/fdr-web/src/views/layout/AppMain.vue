<!--
 * @Descripttion: 主展示区
 * @version:
 * @Author:
 * @Date: 2019-12-10 19:25:45
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-12 17:44:22
 -->
<template>
  <div id="main-wrapper">
    <!-- 显示 fdr 下的所有页面 -->
    <RouterView/>
  </div>
</template>

<script>
import RouterView from './RouterView'
export default {
  name: '',
  data() { 
    return {

    }
  },
  props: {
  },
  components: { RouterView },
  mounted() {
  },
  methods: {
  }
 }
</script>

<style scoped rel="stylesheet/scss" lang="scss">
</style>