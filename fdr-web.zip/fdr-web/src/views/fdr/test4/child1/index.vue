<!--
 * @Descripttion: 
 * @version: 
 * @Author: 
 * @Date: 2019-12-11 12:38:42
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-11 12:38:50
 -->
<template>
  <div class="main-container-block">
    child1
  </div>
</template>

<script>
export default {
  name: '',
  data() { 
    return {

    }
  },
  props: {
  },
  components: {
  },
  mounted() {
  },
  methods: {
  },
 }
</script>

<style scoped rel="stylesheet/scss" lang="scss">
</style>