<!--
 * @Descripttion: 
 * @version: 
 * @Author: 
 * @Date: 2019-12-11 12:39:02
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-11 12:39:09
 -->
<template>
  <div class="main-container-block">
    child2
  </div>
</template>

<script>
export default {
  name: '',
  data() { 
    return {

    }
  },
  props: {
  },
  components: {
  },
  mounted() {
  },
  methods: {
  },
 }
</script>

<style scoped rel="stylesheet/scss" lang="scss">
</style>