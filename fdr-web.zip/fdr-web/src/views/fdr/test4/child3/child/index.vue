<!--
 * @Descripttion: 
 * @version: 
 * @Author: 
 * @Date: 2019-12-11 12:40:10
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-11 19:21:09
 -->
<template>
  <div class="main-container-block">
    childxxx
  </div>
</template>

<script>
export default {
  name: '',
  data() { 
    return {

    }
  },
  props: {
  },
  components: {
  },
  mounted() {
  },
  methods: {
  },
 }
</script>

<style scoped rel="stylesheet/scss" lang="scss">
</style>