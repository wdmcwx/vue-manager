<!--
 * @Descripttion: 
 * @version: 
 * @Author: 
 * @Date: 2019-12-11 10:28:03
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-11 10:28:11
 -->
<template>
  <div class="main-container-block">
    test3
  </div>
</template>

<script>
export default {
  name: '',
  data() { 
    return {

    }
  },
  props: {
  },
  components: {
  },
  mounted() {
  },
  methods: {
  },
 }
</script>

<style scoped rel="stylesheet/scss" lang="scss">
</style>