<!--
 * @Descripttion: 
 * @version: 
 * @Author: 
 * @Date: 2019-12-11 10:27:32
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-11 10:27:42
 -->
<template>
  <div class="main-container-block">
    test2
  </div>
</template>

<script>
export default {
  name: '',
  data() { 
    return {

    }
  },
  props: {
  },
  components: {
  },
  mounted() {
  },
  methods: {
  },
 }
</script>

<style scoped rel="stylesheet/scss" lang="scss">
</style>