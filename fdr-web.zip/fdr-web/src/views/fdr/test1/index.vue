<!--
 * @Descripttion: 
 * @version: 
 * @Author: 
 * @Date: 2019-12-11 10:27:07
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-12 19:22:55
 -->
<template>
  <div class="main-container-block">
    <table-pagination :tableData="tableData" :tableDataTitle="tableDataTitle">
      <el-table-column
        type="selection"
        width="55">
      </el-table-column>
      <el-table-column v-for="(item, index) in Object.keys(tableData[0])" :key="index"
        :prop="item"
        :label="tableDataTitle[item]"
        align="center">
      </el-table-column>
    </table-pagination>
  </div>
</template>

<script>
import tablePagination from 'components/TablePagination'
export default {
  name: '',
  data() { 
    return {
      tableDataTitle: {
        date: '日期',
        name: '姓名',
        address: '地址'
      }
    }
  },
  props: {},
  components: { tablePagination },
  mounted() {},
  computed: {
    tableData() {
      let tempArr = []
      for (let i = 0; i < 30; i++) {
        tempArr[i] = {
          date: i + 1,
          name: 'index ' + (i + 1),
          address: '上海市 ' + (i + 1)
        } 
      }

      return tempArr
    }
  },
  methods: {
  },
 }
</script>

<style scoped rel="stylesheet/scss" lang="scss">
</style>