<!--
 * @Descripttion: 页面主入口
 * @version: 
 * @Author: 
 * @Date: 2019-12-10 15:35:30
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-10 19:45:11
 -->
<template>
  <div id="app">
    <!-- 显示的页面由路由控制 -->
    <router-view v-if='isRouterAlive'/>
  </div>
</template>

<script>
export default {
  name: 'app',
  components: {
  },
  created() {
  },
  data() {
    return {
      isRouterAlive: true
    }
  },
  provide() {
    return {
      reload: this.reload
    }
  },
  methods: {
    // 刷新方法
    reload: function() {
      this.isRouterAlive = false
      // 该方法会在dom更新后执行
      this.$nextTick(function() { this.isRouterAlive = true })
    }
  }
}
</script>

<style>
</style>
