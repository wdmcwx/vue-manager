/*
 * @Descripttion: webpack配置入口
 * @version: 
 * @Author: 
 * @Date: 2019-12-10 16:00:00
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-11 12:29:22
 */
const path = require('path')
function resolve(dir) {
  return path.join(__dirname, dir)
}
module.exports = {
  lintOnSave: false,
  publicPath: './',
  chainWebpack: config => {
    setAlias(config)
  }
}

function setAlias(config) {
  return config.resolve.alias
    .set("views", path.resolve(__dirname, './src/views'))
    .set("utils", path.resolve(__dirname, './src/utils'))
    .set("@", resolve("src"))
    .set("store", path.resolve(__dirname, './src/store'))
    .set("styles", path.resolve(__dirname, './src/styles'))
    .set("filters", path.resolve(__dirname, './src/filters'))
    .set("mixins", path.resolve(__dirname, './src/mixins'))
    .set("mock", path.resolve(__dirname, './src/mock'))
    .set("router", path.resolve(__dirname, './src/router'))
    .set("assets", path.resolve(__dirname, './src/assets'))
    .set("api", path.resolve(__dirname, './src/api'))
    .set("components", path.resolve(__dirname, './src/components'))
}