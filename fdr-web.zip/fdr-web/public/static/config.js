/*
 * @Descripttion: 
 * @version: 
 * @Author: 
 * @Date: 2019-12-10 15:45:01
 * @LastEditors: wdm
 * @LastEditTime: 2019-12-10 15:45:29
 */
// 修改服务器地址
const VUE_APP_BASE_URL = 'xxxxxxxx'